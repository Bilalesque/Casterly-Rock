function validateForm() {
    /*var x = document.forms["regform"]["firstname"].value;
    if (x == "") {
        alert("First Name must be filled out");
        return false;
    }
    var y = document.forms["regform"]["lastname"].value;
    if (y == "") {
        <?php
            echo"Fill the LAst NAme"l;
        ?>
        return false;
    }*/
}