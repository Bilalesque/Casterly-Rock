<!DOCTYPE html>
<html lang="en">
<head>
<title>Rooms</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Adamina_400.font.js"></script>
<script type="text/javascript" src="js/formvalidate.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
<script type="text/javascript" src="js/script.js" ></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" href="css/ie.css" type="text/css" media="all">
<![endif]-->
</head>
<body id="page4">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
          <li><a href="rooms.html"><img src="images/logo.png" height="120px" width="300px" alt=""></a> </li>
      </header>
      <div class="box">
        <nav>
          <ul id="menu">
            <li><a href="index.html">Home</a></li>
            <li ><a href="rooms.html">Room Packages</a></li>
            <li><a href="Gastronomy.html">Gastronomy</a></li>
            <li><a href="events.html">Events</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="facilities.html">Facilities</a></li>
            <li class="active"><a href="reg.php">Reservation</a></li>
            </ul>
        </nav>
          

          
          
          
          
          <?php

$fnameErr = $lnameErr = $addressErr = $phoneNumberErr= $NOPErr= $categoryrErr = "";
$fname = $lname = $addr = $pno = $nop = $cat = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
  if (empty($_POST["firstname"])) 
  {
    $fnameErr = "*";
  } 
  else 
  {
    $fname = ($_POST["firstname"]);
  }

  if (empty($_POST["lastname"])) 
  {
    $lnameErr = "*";
  } 
  else 
  {
    $lname = $_POST["lastname"];
  }
   
  if (empty($_POST["Address"])) 
  {
    $addressErr = "*";
  } 
  else 
  {
    $addr = ($_POST["firstname"]);
  }

  if (empty($_POST["PhoneNumber"])) 
  {
    $phoneNumberErr = "*";
  } 
  else 
  {
    $pno = ($_POST["lastname"]);
  }
    
}
?>

          
          
          
          
          
          
          
          
     <div id=frm>
      
   <form action="<?php echo ($_SERVER['PHP_SELF']);?>"  method="post" name="regform" method="post">
   
        <h2 class="bilal" style="color:#b09012">Personal Information</h2>    
    
    
        <input type="text" name="firstname" placeholder="First Name"/>
        <span class="error"><?php echo $fnameErr; ?></span>
        <br>
    
        <input type="text" name="lastname" placeholder="Last Name"/>
        <span class="error"><?php echo $lnameErr;?></span>
        <br>
    
        <input type="text" name="Address" placeholder="Address"/>
        <span class="error"><?php echo $addressErr;?></span>
        <br>
    
        <input type="text" name="PhoneNumber" placeholder="Phone Number"/>
        <span class="error"><?php echo $phoneNumberErr;?></span>
        <br>
    
        <input type="text" name="NOP"  placeholder="No Of People"/>    
        <br>
        
        <input type="radio" name="category" value="CA">Company Affiliated
        <input type="radio" name="category" value="ID">Independent
    
       <br>
    
    <input type="submit" value="Submit" class="subbutton">
   
   </form>
      
          </div>
        </div>
    </div>  
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
</body>
</html>