﻿<?php

if (!isset($_SESSION))
{
  session_start();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Casterly Rock</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/jquery-ui.css" type="text/css">

<script type="text/javascript" src="js/jquery-1.6.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Adamina_400.font.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
<script type="text/javascript" src="js/script.js" ></script>
<script type="text/javascript" src="js/kwicks-1.5.1.pack.js" ></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>

<script>
  $(document).ready(function() {
    $(".datepicker").datepicker();
  });
  </script>
    
</head>
<body id="page1">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
          <li><a href="index.php"><img src="images/logo.png" height="120px" width="300px" alt=""></a> </li>
      </header>
      <div class="box">
          <nav>
          <ul id="menu">
            <li class="active"><a href="index.php">Add Employees</a></li>
            <li><a href="View.php">View Details</a></li>
            </ul>
        </nav>
        
        <!-- header end -->
        <!-- content -->
        <article id="content">
          <div class="box1">
            <div class="wrapper">
            
                     
<h2 style='text-align: center; color: black; font-size: 30px'>ADMIN PANEL FOR ADDING EMPLOYEE
    
    
    <div id="frm">
  <form action="#" method="post" name="roombook">
    
      <table style="margin-left: 240px;margin-right: 150px; margin-top: 10px;margin-bottom: 10px;table-layout: fixed;">
         <tr>
          <td> 
            <input type="text" name="firstname" placeholder="First Name" id="firstname" required/>
            <span class="error" ng-show="regform.firstname.$touched && regform.firstname.$invalid"></span>
          </td>
          <td>
            <input type="text" id="lastname" name="lastname" placeholder="Last Name"  required/>
            <span class="error" ng-show="regform.lastname.$touched && regform.lastname.$invalid"></span>          
          </td>
         </tr>
         <tr>
          <td>
              <input type="text" id="cnic" name="cnic" placeholder="CNIC"  required/>
              <span class="error" ng-show="regform.cnic.$touched && regform.cnic.$invalid"></span>
           </td>
          <td>
              <input type="text" id="Address" name="Address" placeholder="Address"  required/>
              <span class="error" ng-show="regform.Address.$touched && regform.Address.$invalid"></span>
          </td>
         </tr>
         <tr>
          <td>
              <input type="number" id="PhoneNumber" name="PhoneNumber" placeholder="Phone Number"  required/>
              <span class="error" ng-show="regform.number.$touched && regform.number.$invalid"></span>
          </td>
          <td>
              <input type="email" id="Email" name="Email" ng-model="Email" placeholder="Email"  required/>
              <span class="error" ng-show="regform.Email.$touched && regform.Email.$invalid"></span>
          </td>
          </tr>
          <tr>
          <td>
              <input type="text" name="pm" id="pm" placeholder="Credit Card Number"  required/>
              <span class="error" ng-show="regform.pm.$touched && regform.pm.$invalid"></span>
          </td>
          <td>
              <input style="background-color : black; border-radius: 20px; color: white; margin: 20px; padding: 15px" class="datepicker" placeholder="Hire Date" name="Dp" required/>
         </td>
        </tr>
       </table>   
    <input type="submit" value="Submit" class="subbutton" style="margin: 35px;">
    <input type="reset" value="Cancel" class="subbutton" style="margin: 35px;">
   
    
</form>
          </div>
              
    
    
               </h2>
            </div>
            <div class="pad">
              <div class="line1">
              </div>
            </div>
        </div>  
          <div class="pad">
            <div class="wrapper line3">
              
            </div>
          </div>
        </article>
        <!--content end-->
      </div>
    </div>
  </div>
</div>
    
     <div class="main">
  <!-- footer -->
  <footer>
    <div class="col2">
        
        <h2>LOCATION 
        </h2>
        <p>
            SHAH LATIF TOWN, NEAR BHAINS COLONY KARACHI,PAKISTAN
        </p>
        <h2>CONTACT NUMBER
        </h2>    
        <p>
            021-987654321
        </p>
    </div>
    <!-- {%FOOTER_LINK} -->
  </footer>
  <!-- footer end -->
</div>
   
    
    
<script type="text/javascript">Cufon.now();</script>
<script type="text/javascript">
$(document).ready(function () {
    $('.kwicks').kwicks({
        max: 500,
        spacing: 0,
        event: 'mouseover'
    });
})
</script>
</body>
</html>