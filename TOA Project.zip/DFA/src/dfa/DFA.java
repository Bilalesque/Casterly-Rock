/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfa;

/**
 *
 * @author Lenovo
 */
import java.awt.EventQueue;
import java.util.Scanner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class DFA {

    private static class States {

        boolean accept;

        public States(boolean s) {
            accept = s;
        }

        public void setStatus(boolean accept) {
            this.accept = accept;
        }

        public boolean checkStatus() {
            return accept;
        }
    }
    States q0, q1, q2, r, current;
    String trans;

    public DFA() {
        q0 = new States(true);
        q1 = new States(true);
        q2 = new States(false);
        r = new States(false);
    }

    public void tupleSet() {
        JOptionPane.showMessageDialog(null, "\nStates   {q0 , q1 , q2 ,r}\nALphabets:   {a , b} \nInitial State   {q0} \nFinal State   {q0 , q1} \nTransition Function   6 = Q * E => Q", "TUPLE SET", 1);
    }

    public void transitonFunction() {
        JOptionPane.showMessageDialog(null, "\n STATES           ALPHABETS " + "\n                              a            b " + "\n\n" + "*->q0                    q1         q0" + "\n  *q1                      q2           r" + "\n    q2                      r            q1", "\nTRANSITION TABLE: \n", 1);
    }

    public States check(String str) {
        States current = q0;
        String transition = "";
        if (str.length() == 0) {
            current = r;
            transition = "Empty String. ";
            trans = transition;
            return current;
        }
        for (int i = 0; i < str.length() || current == r; i++) {
            if (str.charAt(i) != 'a' && str.charAt(i) != 'b') {
                current = r;
                transition = "Alphabets Not Supported. ";
                trans = transition;
                return current;
            }
            if (str.charAt(i) == 'b' && current == q0) {
                current = q0;
                transition = transition.concat("{q0,b}->q0\n");
            } else if (str.charAt(i) == 'a' && current == q0) {
                current = q1;
                transition = transition.concat("{q0,a}->q1\n");
            } else if (str.charAt(i) == 'b' && current == q1) {
                current = r;
                transition = transition.concat("{q1,b}->r\n");
                trans = transition;
                return current;
            } else if (str.charAt(i) == 'a' && current == q1) {
                current = q2;
                transition = transition.concat("{q1,a}->q2\n");
            } else if (str.charAt(i) == 'b' && current == q2) {
                current = q1;
                transition = transition.concat("{q2,b}->q1\n");
            } else if (str.charAt(i) == 'a' && current == q2) {
                current = r;
                transition = transition.concat("{q2,a}->r\n");
                trans = transition;
                return current;
            }
            trans = transition;
        }
        return current;
    }

    public void Test(String str) {
        States current = check(str);
        if (current.checkStatus() == true) {
            JOptionPane.showMessageDialog(null, trans + "\t\tString Accepted!\n", "TRANSITION TEST", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, trans + "Invalid String!\n", "TRANSITION TEST", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        DFA dfa = new DFA();
        String que;
        int a = 1;

        while (a == 1) {

            String string = JOptionPane.showInputDialog("STRING TEST FOR REGULAR EXPRESSION" + "\nAlphabet: {a,b}" + "\nExpression: b*a(ab)*+b*\n" + "\n\n\n1)String Input\n2)For showing the tuple set \n3)For showing the Transition Table\n4)For Image of DFA \n5)Exit");

            switch (string) {
                case "1": {
                    que = JOptionPane.showInputDialog("\nEnter The String: ");
                    dfa.Test(que);
                    break;
                }
                case "2": {
                    dfa.tupleSet();
                    break;
                }
                case "3": {
                    dfa.transitonFunction();
                    break;
                }
                case "4": {
                    EventQueue.invokeLater(() -> {
                        Displaymage ex = new Displaymage();
                        ex.setVisible(true);
                    });
                    break;
                }
                case "5": {
                    JOptionPane.showMessageDialog(null, "Mohammad Bilal Shafique ", "MADE BY", 1);
                    System.exit(0);
                }
                default: {
                    JOptionPane.showMessageDialog(null, "NO SUCH CHOICE MENTIONED", "ERROR", 2);
                }
            }

        }
    }
}
