package com.example.bilalsalman.hogwartsexpress;


import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import android.widget.ImageView;

public class SignUp extends AppCompatActivity {


    public static final int PICK_IMAGE = 100;

    Button uploadimage;
    ImageView imageview;
    Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
          uploadimage = findViewById((R.id.uploadimage));
          imageview = findViewById(R.id.imageView);

        uploadimage.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
              openGallery();
            }
        });
 }

        private void openGallery(){

            Intent myIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
            startActivityForResult(myIntent, PICK_IMAGE);
        }

        @Override
    protected void onActivityResult(int RequestCode, int ResultCode, Intent data)
        {
            super.onActivityResult(RequestCode,ResultCode,data);
            if(ResultCode == RESULT_OK && RequestCode == PICK_IMAGE)
            {
                imageUri = data.getData();
                imageview.setImageURI(imageUri);
            }
        }
}
