package com.example.bilalsalman.hogwartsexpress;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity{

    Button signup,signin;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        signup = findViewById(R.id.register);
        signin = findViewById(R.id.signin);


        signup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                Intent myIntent = new Intent(Login.this, SignUp.class);
                startActivity(myIntent);
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                EditText uname = findViewById(R.id.username);
                EditText pass = findViewById(R.id.pass);

                if(uname.getText().toString().equals("customer") && pass.getText().toString().equals("customer"))
                {
                    Toast.makeText(getApplicationContext(), "Signing in...",
                            Toast.LENGTH_SHORT).show();

                    Intent myIntent = new Intent(Login.this, customernavigation.class);
                    startActivity(myIntent);
                }

                else if(uname.getText().toString().equals("admin") && pass.getText().toString().equals("admin"))
                {
                    Toast.makeText(getApplicationContext(), "Going To Admin Panel",
                            Toast.LENGTH_SHORT).show();

                    Intent myIntent = new Intent(Login.this, navigation.class);
                    startActivity(myIntent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Invalid username or password",
                            Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}
