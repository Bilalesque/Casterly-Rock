<?php
if (!isset($_SESSION))
{
  session_start();
}
if(!isset($_SESSION['roomType']) && !isset($_SESSION['diningtype']) && !isset($_SESSION['type12']))
{
  header('location:reg.php?err=Invalid Registration');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Personal Information Form</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Adamina_400.font.js"></script>
<script type="text/javascript" src="js/formvalidate.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
<script type="text/javascript" src="js/script.js" ></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
    <script type="text/javascript" src="js/angular.min.js">
    </script>
    <script type="text/javascript" src="js/validateform.js">
    </script>
    <script type="text/javascript" src="js/dropdownform.js">
    </script>
    
</head>
<body id="page4">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
          <li><a href="index.html"><img src="images/logo.png" height="120px" width="300px" alt=""></a> </li>
      </header>
      
      <div class="box">
     
      


<?php

$fname = $lname = $cnic = $address = $pnumber = $email = $cnumber = "";
$rdate = $category = "";
  

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

  if (!empty($_POST["firstname"])) 
  {
    $fname = $_POST["firstname"];
    $_SESSION["fname"] = $fname;
  } 
 
 if (!empty($_POST["lastname"])) 
  {
    $lname = $_POST["lastname"];
    $_SESSION["lname"] = $lname;
  }

  if (!empty($_POST["cnic"])) 
  {
    $cnic = $_POST["cnic"];
    $_SESSION["cnic"] = $cnic;
  }

if (!empty($_POST["Address"])) 
  {
    $address = $_POST["Address"];
    $_SESSION["address"] = $address;
  }

  if (!empty($_POST["Email"])) 
  {
    $email = $_POST["Email"];
    $_SESSION["email"] = $email;
  }
  
  if (!empty($_POST["pm"])) 
  {
    $cnumber = $_POST["pm"];
    $_SESSION["cnumber"] = $cnumber;
  }

 if (!empty($_POST["PhoneNumber"])) 
  {
    $pnumber = $_POST["PhoneNumber"];
    $_SESSION["pnumber"] = $pnumber;
  }


  if (!empty($_POST["Dp"])) 
  {
    $rdate = $_POST["Dp"];
    $_SESSION["rdate"] = $rdate;
  }

  if (!empty($_POST["category"])) 
  {
    $category = $_POST["category"];
    $_SESSION["category"] = $category;
  }  
}
?>

     <h1 style='margin-left: 80px; margin-bottom: 40px; color: black; font-size: 30px'>     PERSONAL INFORMATION FORM CONFIRMATION PAGE</h1>
  


<h2 style='text-align: center; color: black; font-size: 30px'>PERSONAL INFO</h2>

     <br>


     <p style="font-size: 18px">
        <bold>First Name: </bold> <?php echo $_SESSION["fname"]; ?>
     </p>


      <p style="font-size: 18px">
        <bold>Last Name: </bold> <?php echo $_SESSION["lname"]; ?>
     </p>

      <br>
     
     <p style="font-size: 18px">
        <bold>CNIC: </bold> <?php echo $_SESSION["cnic"]; ?>
     </p>

<p style="font-size: 18px">
        <bold>Address: </bold> <?php echo $_SESSION["address"]; ?>
     </p>

     <p style="font-size: 18px">
        <bold>PhoneNumber: </bold> <?php echo $_SESSION["pnumber"]; ?>
     </p>

     <p style="font-size: 18px">
        <bold>Email: </bold> <?php echo $_SESSION["email"]; ?>
     </p>

     <p style="font-size: 18px">
        <bold>Credit Card No: </bold> <?php echo $_SESSION["cnumber"]; ?>
     </p>

     <p style="font-size: 18px">
        <bold>Reservation Date: </bold> <?php echo $_SESSION["rdate"]; ?>
     </p>

      <p style="font-size: 18px">
        <bold>Category: </bold> <?php echo $_SESSION["category"]; ?>
     </p>


<br>
     <br>     



    <br>
     <br>

      <h2 style='text-align: center; color: black; font-size: 30px'>     ROOM BOOKING INFO</h2>

    
     <br>
     <p style="font-size: 18px">
        <bold>Room Type: </bold> <?php  if(isset($_SESSION['roomType']))
             echo $_SESSION["roomType"];
          else
           echo "NOT SELECTED"; ?>
     </p>

     <br>

      <p style="font-size: 18px">
        <bold>Number Of Rooms: </bold> <?php  if(isset($_SESSION['NumbeOfRooms']))
             echo $_SESSION["NumbeOfRooms"];
          else
           echo "NOT SELECTED"; ?>
     </p>

      <br>
     
     <p style="font-size: 18px">
        <bold>Number Of Beds: </bold> <?php  if(isset($_SESSION['numberOfBeds']))
             echo $_SESSION["numberOfBeds"];
          else
           echo "NOT SELECTED"; ?>
     </p>

     <p style="font-size: 18px">
        <bold>Checkout Date: </bold> <?php if(isset($_SESSION["cdate"])) 
        	echo $_SESSION["cdate"];
        	else
        		echo "NOT SELECTED";
        ?>
     </p>

<br>
     <br>
    
     <h2 style='text-align: center; color: black; font-size: 30px'>     DINING RESERVATION INFO</h2>


     <br>
     <p style="font-size: 18px">
        <bold>Dining Type: </bold> <?php  if(isset($_SESSION['diningtype']))
             echo $_SESSION["diningtype"];
          else
           echo "NOT SELECTED"; ?>
     </p>


      <p style="font-size: 18px">
        <bold>Number Of Diners: </bold> <?php  if(isset($_SESSION['diningnum']))
             echo $_SESSION["diningnum"];
          else
           echo "NOT SELECTED"; ?>
     </p>

     
     <p style="font-size: 18px">
        <bold>Meal Selected: </bold> <?php  if(isset($_SESSION['measlselect']))
             echo $_SESSION["measlselect"];
          else
           echo "NOT SELECTED"; ?>
     </p>

<br>
     <br>


<h2 style='text-align: center; color: black; font-size: 30px'>     EVENT BOOKING INFO</h2>

     <br>
     <p style="font-size: 18px">
        <bold>Event Type: </bold> <?php 


          if(isset($_SESSION['type12']))
             echo $_SESSION["type12"];
          else
           echo "NOT SELECTED";?>
     </p>

     
      <p style="font-size: 18px">
        <bold>Capacity: </bold> <?php 
        if(isset($_SESSION['capacity']))
             echo $_SESSION["capacity"];
          else
           echo "NOT SELECTED"; ?>
     </p>

      <br>
     <br>
     

          <h2 style='text-align: center; color: black; font-size: 30px'>     SERVICES SELECTION INFO</h2>
     <br>
      
      <p style="font-size: 18px;margin-left: 20px"><bold>Valet Service: </bold> 
        <?php  if(isset($_SESSION['v']))
                  echo '-> ', $_SESSION["v"];
          else
           echo "NOT SELECTED";?>
        
     </p>
      <p style="font-size: 18px;margin-left: 20px"><bold>Room Cleaning: </bold> 
        <?php if(isset($_SESSION['rc']))
                echo '-> ', $_SESSION["rc"];
          else
           echo "NOT SELECTED"; ?> 
     </p>
     
     <p style="font-size: 18px;margin-left: 20px"><bold>Food Service: </bold> 
        <?php  if(isset($_SESSION['rs']))
                echo '-> ', $_SESSION["rs"];
              else
                echo "NOT SELECTED"; ?>
     </p>

      <br>
     <br>


     <h2 style='text-align: center; color: black; font-size: 30px'>     FACILITIES SELECTION INFO</h2>


     <br>
     
      <p style="font-size: 18px;margin-left: 20px"><bold>Swimming: </bold> 
        <?php if(isset($_SESSION['s']))
                echo '-> ', $_SESSION["s"];
              else
                echo "NOT SELECTED"; ?>
     </p>
      <p style="font-size: 18px;margin-left: 20px"><bold>Fitness Center: </bold> 
        <?php if(isset($_SESSION['fc']))
                echo '-> ', $_SESSION["fc"];
              else
                echo "NOT SELECTED"; ?>
     </p>
     
     <p style="font-size: 18px;margin-left: 20px"><bold>Indoor Sports: </bold> 
        <?php if(isset($_SESSION['is']))
                echo '-> ', $_SESSION["is"];
              else
                echo "NOT SELECTED"; ?>
     </p>

     <p style="font-size: 18px;margin-left: 20px"><bold>Spa: </bold> 
        <?php if(isset($_SESSION['spa']))
                echo '-> ', $_SESSION["spa"];
              else
                echo "NOT SELECTED"; ?>
     </p>
      
      <br>
     <br>



            <?php
session_unset(); 

session_destroy(); 
?>

            <li style="float: right; color: white; font-size: 30px; list-style-type: none;
    "> <a href="reg.php"> <strong>Click Here To Continue</strong> </a> </li>



        </div>
    </div>  
  </div>
</div>   
    
    
    
<script type="text/javascript">Cufon.now();</script>
</body>
</html>