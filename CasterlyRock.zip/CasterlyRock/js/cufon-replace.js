Cufon.replace('#menu a, h2', { fontFamily: 'Adamina', hover:true });

