/*<script>
function onChangeOfValue(regform)
{
  var oldValue = regform.defaultValue;
  var newValue = regform.value;
  if (window.confirm("do you really want to change the value to " + newValue + "?")) 
   {
    regform.defaultValue = newValue;
  } else {
    regform.value =regform.defaultValue;
  } 
}
</script>

<input onchange="onChangeOfValue(this);">
    */