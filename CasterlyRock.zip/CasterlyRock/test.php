<?php 

session_start();

 ?>


 <?php 

$_SESSION['ahmed']="a";

if(!empty($_SESSION['ahmed']))
	echo "string";
else
	echo "123";

  ?>