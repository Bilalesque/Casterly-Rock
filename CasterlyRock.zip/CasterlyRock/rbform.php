<!DOCTYPE html>
<html lang="en">
<head>
<title>Room Booking Form</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Adamina_400.font.js"></script>
<script type="text/javascript" src="js/formvalidate.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
<script type="text/javascript" src="js/script.js" ></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
    <script type="text/javascript" src="js/angular.min.js">
    </script>
    <script type="text/javascript" src="js/validateform.js">
    </script>
    <script type="text/javascript" src="js/dropdownform.js">
    </script>
    
</head>
<body id="page4">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
          <li><a href="index.html"><img src="images/logo.png" height="120px" width="300px" alt=""></a> </li>
      </header>
      
      <div class="box">
     
      


<?php

$roomType = $numberOfBeds = $NumbeOfRooms = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

  if (!empty($_POST["sel1"])) 
  {
    $roomType = $_POST["sel1"];
  } 

  if (!empty($_POST["sel2"])) 
  {
    $NumbeOfRooms = $_POST["sel2"];
  } 
   
  if (!empty($_POST["sel3"])) 
  {
    $numberOfBeds = $_POST["sel3"];
  } 


    /*if(!empty($_POST["sel1"]) && !empty($_POST["sel2"]) && !empty($_POST["sel3"]))
    {
         echo "<br>Room Type: ", $roomType;
         echo "<br>Number Of Rooms: ", $NumbeOfRooms;
         echo "<br>Number Of Beds: ", $numberOfBeds;
         echo "<br>Room Booking Confirmed ";
    }  */ 
    
}
?>

     <h1 style='margin-left: 80px; color: black; font-size: 30px'>     ROOM BOOKING FORM CONFIRMATION PAGE</h1>

     <br>
     <br>
     <br>
     <br>


     <p style="font-size: 18px">
        <bold>Room Type: </bold> <?php echo $roomType; ?>
     </p>

     <br>

      <p style="font-size: 18px">
        <bold>Number Of Rooms: </bold> <?php echo $NumbeOfRooms; ?>
     </p>

      <br>
     
     <p style="font-size: 18px">
        <bold>Number Of Beds: </bold> <?php echo $numberOfBeds; ?>
     </p>

<br>
     <br>
     
              
            <li style="float: right; color: white; font-size: 30px; list-style-type: none;
    "> <a href="Rb.php"> <strong>Click Here To Continue</strong> </a> </li>
            
        



        </div>
    </div>  
  </div>
</div>   
    
    
    
<script type="text/javascript">Cufon.now();</script>
</body>
</html>