<!DOCTYPE html>
<html lang="en">
<head>
<title>Gastronomy Booking</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Adamina_400.font.js"></script>
<script type="text/javascript" src="js/formvalidate.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
<script type="text/javascript" src="js/script.js" ></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
    <script type="text/javascript" src="js/angular.min.js">
    </script>
    <script type="text/javascript" src="js/validateform.js">
    </script>
    <script type="text/javascript" src="js/dropdownform.js">
    </script>
    
</head>
<body id="page4">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
          <li><a href="index.html"><img src="images/logo.png" height="120px" width="300px" alt=""></a> </li>
      </header>
      <div class="box">
        <nav>
          <ul id="menu">
            <li><a href="index.html">Home</a></li>
            <li ><a href="rb.php">Room Packages</a></li>
            <li><a href="Gastronomy.php">Gastronomy</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="facilities.php">Facilities</a></li>
            <li class="active"><a href="gs.php">Gastronomy</a></li>
            </ul>
        </nav>
          

  <div id="frm">
  <form action="gsform.php" method="post" name="gasbook">
    
    <h2 class="bilal" style="color:#b09012; margin-top: 20px;margin-bottom: 10px ">Dining Reservation</h2>

 Select Type of Dining:
  <select style="margin: 7px" ng-model="myVar" name="s1" required>
    <option value=""> </option>
    <option value="On-Order">On-Order </option>
    <option value="Buffet">Buffet </option>
  </select>
<br>Select Number of Diners:
  <select style="margin: 7px" ng-model="myVar" name="s2" required>
    <option value=""> </option>
    <option value="Table for One">Table for One </option>
    <option value="Table for Two">Table for Two </option>
    <option value="Table for Three">Table for Three </option>
    <option value="Table for Four">Table for Four </option>
  </select>
<br> Select Meal:
  <select style="margin: 7px" ng-model="myVar" name="s3" required>
    <option value=""> </option>
    <option value="Breakfast">Breakfast </option>
    <option value="Lunch">Lunch </option>
    <option value="Dinner">Dinner </option>
  </select>
  <br>
  <input type="submit" value="Book" class="subbutton" style="padding: 9px">
  <input type="reset" value="Cancel" class="subbutton" style="padding: 9px">
</form>
          </div>
        </div>
    </div>  
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
</body>
</html>

