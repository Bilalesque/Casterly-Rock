<!DOCTYPE html>
<html lang="en">
<head>
<title>Reservation</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/jquery-ui.css" type="text/css">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/jquery-ui.css" type="text/css">
<script type="text/javascript" src="js/lib2.js">
</script>
<script type="text/javascript" src="js/jquery-1.6.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Adamina_400.font.js"></script>
<script type="text/javascript" src="js/formvalidate.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
<script type="text/javascript" src="js/script.js" ></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
    <script type="text/javascript" src="js/angular.min.js">
    </script>
    <script type="text/javascript" src="js/validateform.js">
    </script>
    <script type="text/javascript" src="js/dropdownform.js">
    </script>
    <script type="text/javascript" src="js/lib1.js">
    </script>

    
<script>
  $(document).ready(function() {
    $(".datepicker").datepicker();
  });
  </script>

</head>
<body id="page4">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
          <li><a href="index.php"><img src="images/logo.png" height="120px" width="300px" alt=""></a> </li>
      </header>
      <div class="box">
        <nav>
          <ul id="menu">
            <li><a href="index.php">Home</a></li>
            <li ><a href="Rb.php">Room Packages</a></li>
            <li><a href="Gastronomy.php">Gastronomy</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="facilities.php">Facilities</a></li>
            <li class="active"><a href="reg.php">Reservation</a></li>
            </ul>
        </nav>
          

          
          
          
          
<?php

$fnameErr = $lnameErr = $addressErr = $phoneNumberErr = $categoryrErr = $emailerr = "";
$fname = $lname = $addr = $pno = $cat = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
  if (empty($_POST["firstname"])) 
  {
    $fnameErr = "";
  } 
  else 
  {
    $fname = ($_POST["firstname"]);
  }

  if (empty($_POST["lastname"])) 
  {
    $lnameErr = "";
  } 
  else 
  {
    $lname = $_POST["lastname"];
  }
   
  if (empty($_POST["Address"])) 
  {
    $addressErr = "";
  } 
  else 
  {
    $addr = ($_POST["Address"]);
  }

  if (empty($_POST["PhoneNumber"])) 
  {
    $phoneNumberErr = "";
  } 
  else 
  {
    $pno = ($_POST["PhoneNumber"]);
  }
  if (empty($_POST["Email"]))
  {
      $emailerr = "";
  }
  else
  {
      $email = ($_POST["Email"]);
  }
    if(!empty($_POST["PhoneNumber"]) && !empty($_POST["Address"]) && !empty($_POST["lastname"]) && !empty($_POST["firstname"]) && !empty($_POST["Email"]) && !empty($_POST["category"]) && !empty($_POST["pm"]) && !empty($_POST["Dp"]) && !empty($_POST["cd"]))
    {
         echo "BOOKING CONFIRMED";
    }   
    
}
?>

     <div id="frm">
      
   <form action="regform.php"  method="post" name="regform">    
       
       <h2 class="bilal" style="color:#b09012; margin-top: 20px;margin-bottom: 10px ">Personal Information</h2>  
        <table style="margin-left: 120px;margin-right: 150px; margin-top: 50px;margin-bottom: 20px;table-layout: fixed;">
         <tr>
          <td> 
            <input type="text" name="firstname" placeholder="First Name" id="firstname" required/>
            <span class="error" ng-show="regform.firstname.$touched && regform.firstname.$invalid"></span>
          </td>
          <td>
            <input type="text" id="lastname" name="lastname" placeholder="Last Name"  required/>
            <span class="error" ng-show="regform.lastname.$touched && regform.lastname.$invalid"></span>          
          </td>
          <td>
              <input type="text" id="cnic" name="cnic" placeholder="CNIC"  required/>
              <span class="error" ng-show="regform.cnic.$touched && regform.cnic.$invalid"></span>
           </td>
         </tr>
         <tr>
          <td>
              <input type="text" id="Address" name="Address" placeholder="Address"  required/>
              <span class="error" ng-show="regform.Address.$touched && regform.Address.$invalid"></span>
          </td>
          <td>
              <input type="number" id="PhoneNumber" name="PhoneNumber" placeholder="Phone Number"  required/>
              <span class="error" ng-show="regform.number.$touched && regform.number.$invalid"></span>
          </td>
          <td>
              <input type="email" id="Email" name="Email" ng-model="Email" placeholder="Email"  required/>
              <span class="error" ng-show="regform.Email.$touched && regform.Email.$invalid"></span>
          </td>
         </tr>
         <tr>
          <td>
              <input type="text" name="pm" id="pm" placeholder="Credit Card Number"  required/>
              <span class="error" ng-show="regform.pm.$touched && regform.pm.$invalid"></span>
          </td>
          <td>
              <input style="background-color : black; border-radius: 20px; color: white; margin: 20px; padding: 15px" class="datepicker" placeholder="Pick Reservation Date" name="Dp" required/>
          </td>
          <td>
              <input style="background-color : black; border-radius: 20px; color: white; margin: 20px; padding: 15px" class="datepicker" placeholder="Pick Checkout Date" name="cd" required/>
          </td>
         </tr>
       </table>   
    <input type="radio" id="CA" name="category" value="Company Affiliated" required>Company Affiliated    
    <input type="radio" id="ID" name="category" value="Independent" required>Independent
    <span ng-show="regform.category.$touched && regform.category.$invalid"></span>
    <br>
    <br>
    <input type="submit" value="Submit" class="subbutton" style="margin: 35px;">
    <input type="reset" value="Cancel" class="subbutton" style="margin: 35px;">
   
   </form>
          <p style="color:red; text-align:left;font-size:12px;margin:20px" >' * ' denotes that filling the field is necessary</p>
          </div>
        </div>
    </div>  
  </div>
</div>
    
    <div class="main">
  <!-- footer -->
  <footer>
    <div class="col2">
        
        <h2>LOCATION 
        </h2>
        <p>
            SHAH LATIF TOWN, NEAR BHAINS COLONY KARACHI,PAKISTAN
        </p>
        <h2>CONTACT NUMBER
        </h2>    
        <p>
            021-987654321
        </p>
      <nav>
          <ul id="footer_menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="Rb.php">Room Packages</a></li>
            <li><a href="Gastronomy.php">Gastronomy</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="facilities.php">Facilities</a></li>
            <li class="active"><a href="reg.php">Reservation</a></li>
            </ul>
      </nav>
    </div>
    <div class="col1 pad_left1">
      <ul id="icons">
        <li><a href="https://pk.linkedin.com" class="normaltip"><img src="images/icon1.jpg" alt=""></a></li>
        <li><a href="https://www.facebook.com" class="normaltip"><img src="images/icon2.jpg" alt=""></a></li>
        <li><a href="#" class="normaltip"><img src="images/icon3.jpg" alt=""></a></li>
        <li><a href="https://twitter.com/login?lang=en" class="normaltip"><img src="images/icon4.jpg" alt=""></a></li>
      </ul>
    </div>
    <!-- {%FOOTER_LINK} -->
  </footer>
  <!-- footer end -->
</div>
   
    
    
    
<script type="text/javascript">Cufon.now();</script>
</body>
</html>